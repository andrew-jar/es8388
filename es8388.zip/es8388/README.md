# ES8388
A desesperate attempt to use ES8388 audio codec driver library for Arduino.
Ported from [ESP32-Rhasspy-Satellite](https://github.com/Romkabouter/ESP32-Rhasspy-Satellite/tree/d286973956e50bb31821c19ea103c8e593aca9bc/PlatformIO/src/devices)
